# 05 — Optional Research Machinery, Modes, and Roles

Named machinery is preserved as optional process instrumentation, not a mandatory topology.

`METHOD_STACK_REFERENCE != MANDATORY_PIPELINE`
`ROLE_LABEL != AUTHORITY`
`MODE_LABEL != MUTATION_PERMISSION`

## Modes
- `DISCUSSION` — concept work; no mutation implied.
- `AUDIT` — verify, attack, reconcile evidence.
- `BUILD-PLAN` — design a change without performing it.
- `BUILD-COMMIT` — perform authorized mutation/execution and read back results.
- `RECOVERY` — reconstruct authoritative state rather than bluff through missing context.
- `CHECKPOINT` — write durable restart state.
- `MERGE` — reconcile branches/artifacts/findings without silent promotion.
- `PROMOTION` — elevate a candidate only after qualification.

If mode is ambiguous and the ambiguity changes mutation obligations, stop mode promotion and ask the owning authority rather than silently blending states.

## Roles
- `R1 Conservative Auditor` — attack overclaim, authority leaks, false completion.
- `R2 Divergent Imagination Engine` — widen candidate space without promotion authority.
- `R3 Evidence Synthesizer` — reconcile evidence, provenance, contradictions, scope.
- `R4 Convergence Refiner` — compress surviving mechanisms and remove unnecessary distinctions.
- `R5 Reality Pressure Engine` — force executable/empirical consequence and attack the survivor.

## Optional machinery
- **PDVER** — Probe / Derive / Verify / Embody / Recurse framing.
- **OARR** — adversarial observation/attack/replay/revision loop.
- **Loop+** — outer research loop for source contact, expansion, isomorph hunting, native translation, control update, experiment pressure, replay.
- **Semantic Helix** — propose the next valuable discriminator / integrate meaning changes.
- **CSC** — bounded cross-surface/cross-system review; no automatic veto/promotion authority.
- **Attention Reservoir** — breadth and neglected-hypothesis pressure; storage does not own selection authority.

Use a named instrument only when it buys a causal job. Do not resume historical choreography automatically.
