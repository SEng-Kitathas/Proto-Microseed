from __future__ import annotations
import json, shutil, subprocess, sys, tempfile
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
PY=sys.executable

def run(root:Path):
    return subprocess.run([PY,str(root/'VERIFY_CANONICAL_SOP.py'),str(root)],capture_output=True,text=True)

def mutate(root:Path, rel:str, old:str, new:str):
    p=root/rel;t=p.read_text(encoding='utf-8');
    if old not in t:raise RuntimeError(f'mutation anchor missing {rel}: {old}')
    p.write_text(t.replace(old,new,1),encoding='utf-8',newline='\n')

def main():
    cases=[]
    # name, function
    cases.append(('candidate_id_collision',lambda r: mutate(r,'00_READ_ME_FIRST.md','R4.0','R3.1')))
    cases.append(('continuity_becomes_proof',lambda r: mutate(r,'00_READ_ME_FIRST.md','CONTINUITY != PROOF','CONTINUITY = PROOF')))
    cases.append(('remembered_pointer_becomes_current',lambda r: mutate(r,'00_READ_ME_FIRST.md','REMEMBERED_POINTER != CURRENT_STATE_EVIDENCE','REMEMBERED_POINTER = CURRENT_STATE_EVIDENCE')))
    cases.append(('res_self_promotes',lambda r: mutate(r,'07C_RESEARCH_EPISTEMIC_SHADOW_PROTOCOL.md','RES_CONTENT != GOVERNING_DOCTRINE','RES_CONTENT = GOVERNING_DOCTRINE')))
    cases.append(('environment_identity_collapsed',lambda r: mutate(r,'06_EXECUTION_RELEASE_AND_ENVIRONMENT_DISCIPLINE.md','SEALED_ARTIFACT != SEALED_ENVIRONMENT','SEALED_ARTIFACT = SEALED_ENVIRONMENT')))
    cases.append(('fixed_transport_limit_reintroduced',lambda r: mutate(r,'06_EXECUTION_RELEASE_AND_ENVIRONMENT_DISCIPLINE.md','No fixed transport limit is universal SOP law','Universal archive part limit is 200000000 bytes')))
    cases.append(('unknown_guessing_allowed',lambda r: mutate(r,'09_UNKNOWN_TRACE_AND_RECOVERY_RULE.md','Never guess across the gap','Guess across the gap when convenient')))
    cases.append(('fresh_chat_blindness_collapse',lambda r: mutate(r,'12_COLD_START_PROTOCOL.md','FRESH_THREAD != FRESH_EVALUATOR_IF_MEMORY_OR_HISTORY_IS_SHARED','FRESH_THREAD = FRESH_EVALUATOR_IF_MEMORY_OR_HISTORY_IS_SHARED')))
    cases.append(('extra_unmanifested_file',lambda r: (r/'SURPRISE.txt').write_text('x',encoding='utf-8')))
    cases.append(('project_specific_contamination',lambda r: (r/'02_ENGINEERING_AUTHORITY_SURFACE.md').write_text((r/'02_ENGINEERING_AUTHORITY_SURFACE.md').read_text(encoding='utf-8')+'\nSpecific project: SPECIFICPROJECT_SENTINEL\n',encoding='utf-8')))
    cases.append(('ancestry_corrupted',lambda r: (r/'ancestry'/'RAHL_ENGINEERING_IN_HOUSE_SOP_SPLIT_CANDIDATE_R3_1_2026-08-29.zip').open('ab').write(b'X')))
    cases.append(('canonical_path_regression',lambda r: (r/'MANIFEST_SHA256.json').write_text((r/'MANIFEST_SHA256.json').read_text(encoding='utf-8').replace('machine/AUTHORITY_CLASSES.json','machine\\\\AUTHORITY_CLASSES.json',1),encoding='utf-8')))
    passed=[]; failed=[]
    for name,fn in cases:
        with tempfile.TemporaryDirectory() as td:
            dst=Path(td)/BASE.name; shutil.copytree(BASE,dst)
            fn(dst)
            cp=run(dst)
            if cp.returncode!=0:passed.append(name)
            else:failed.append({'name':name,'stdout':cp.stdout,'stderr':cp.stderr})
    print(json.dumps({'hostile_cases':len(cases),'rejected_as_expected':len(passed),'unexpected_passes':failed},indent=2))
    return 0 if not failed else 2
if __name__=='__main__':raise SystemExit(main())
