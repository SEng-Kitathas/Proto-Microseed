# Rahl Engineering Canonical SOP — R4.0

Date: 2026-09-02
Status: `CANONICAL_IN_HOUSE_SOP`
Scope: `PROJECT_AGNOSTIC_THREAD_AGNOSTIC_PROCESS_AUTHORITY`
Domain / product / architecture authority: `NONE_BY_INCLUSION`
Parent operational lineage: `R3.1`
Parent adopted ZIP SHA-256: `4d205becc2413889bdb37c6b6ff7513d6f759a7dff1d9f9b8fddaddd8235a278`
Assurance ceiling: `STRUCTURE_MEMBERSHIP_HASH_BINDING_REQUIRED_SEMANTICS_UNIVERSALITY_GUARDS_AND_HOSTILE_MUTATION_ONLY`

This is the canonical default engineering/research SOP for a fresh thread or project when no stronger project-local contract supersedes it.

"Universal" here means project-agnostic process default. It does **not** mean every rule is a law of nature, a product requirement, or a substitute for local safety/legal/contractual obligations.

## Absolute adoption rule
1. Treat continuity artifacts as navigation and preserved state, not automatic current-state proof.
2. Governing intent and standing obligations remain active until superseded by the authority that owns them.
3. Paths, hashes, commits, process IDs, ports, campaign positions, environment facts, and repository states are pointers until live evidence verifies their currentness.
4. Preserve truth and authority classes explicitly; do not flatten them into one confidence tone.
5. Never silently merge branches, promote experiments, resolve contradictions, reconstruct missing history, or infer across unread gaps.
6. Inspect durable evidence first. If a load-bearing unknown or unexplained trace remains, ask the owning authority rather than guess across the gap.
7. Project-local context belongs in project state, not in this universal SOP.

## Truth-state grammar
- `VERIFIED` — directly earned by an appropriate verification path.
- `OBSERVED` — present in evidence without a stronger mechanistic interpretation.
- `INFERRED` — structural interpretation supported by evidence but not directly established.
- `HYPOTHESIZED` — candidate explanation requiring discrimination.
- `INTUITION_SIGNAL` — researcher/operator-origin clue worth preserving without promotion.
- `UNKNOWN` — unresolved and not lawfully collapsible.
- `REJECTED_DEMOTED` — previously live interpretation defeated, narrowed, or superseded.

## State / authority grammar
- `RAW -> SEED -> CANDIDATE -> WORKING -> LOAD_BEARING -> CANON`
- Demotion: `QUESTIONED -> LOCAL_ONLY -> DEPRECATED -> TOMBSTONED`
- `CANON != FINAL`
- `CONTINUITY != PROOF`
- `REMEMBERED_POINTER != CURRENT_STATE_EVIDENCE`
- `PROJECT_LOCAL_OBLIGATION != UNIVERSAL_SOP_LAW`

## Cold-start order
Read `01` through `13` in order. Load project-local state only after the universal authority/continuity rules are understood. Use `12_COLD_START_PROTOCOL.md` as the ingress checklist.
