# 14 — R4.0 Convergence / Cull Ledger

## Purpose
This release converges earlier SOP and continuity work into a project-agnostic cold-start surface.

## Preserved and generalized
- reality/evidence precedence;
- authority classes and conflict resolution;
- uniform donor intake / strip-for-parts;
- composition-first before new primitives;
- bounded discriminator-led hostile campaigns;
- optional research machinery/modes/roles without naming-based authority;
- execution/readback/release discipline;
- environment/reproduction identity contracts;
- UNKNOWN/trace/ask rule;
- Live Shadow + Design Thread Stream;
- Research Epistemic Shadow (RES);
- doctrine/trace/revisit/next-step separation;
- append-oriented promotion/demotion history;
- fresh-evaluator isolation when blinding matters.

## Deliberately culled from active universal SOP
The following classes belong in project/user-specific state and SHALL NOT be baked into a universal cold-start package:
- personal biography or long-horizon project narrative;
- named active projects/repositories and their current authority states;
- exact filesystem paths, endpoints, ports, process/job IDs, commits, tags, hashes, campaign positions, machine profiles, or runtime allocations except package ancestry/evidence identity required to verify this release;
- project-specific Commander/governing intent;
- remembered campaign results and code-level scars that apply only to one project;
- collaborator/contact history;
- person-specific communication, teaching, vocabulary, naming, or coding-language preferences;
- fixed archive part-size limits tied to one transport environment.

These are not declared false or unimportant. They are **out of universal SOP scope** and belong in project contracts, continuity, RES, substrate profiles, or user-preference surfaces.

## Major R4.0 additions
- RES as third core shadow: `Live Shadow = now`, `Design Thread Stream = chronology`, `RES = learned meaning/frontier`.
- explicit continuity hardening H01–H13;
- artifact-class-relative environment identity discipline;
- exact-vs-normalized reproduction assurance separation;
- ecological vs controlled-causal claim separation;
- identifying vs developmental evaluation distinction;
- observation-time subject binding;
- negative-history preservation without fossilization.
