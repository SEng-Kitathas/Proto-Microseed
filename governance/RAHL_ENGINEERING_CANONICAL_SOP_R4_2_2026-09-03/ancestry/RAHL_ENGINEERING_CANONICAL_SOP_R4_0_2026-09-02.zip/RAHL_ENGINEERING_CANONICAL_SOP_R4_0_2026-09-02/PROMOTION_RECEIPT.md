# Canonical Promotion Receipt — R4.0

Date: 2026-09-02
Disposition: `PROMOTED_TO_CANONICAL_IN_HOUSE_SOP`
Scope: project-agnostic / thread-agnostic process and cold-start authority.

## Basis
- operator explicitly requested a canonical SOP suitable for dropping into any new thread;
- project/person/runtime-state material was culled from the active universal surface rather than laundered into generic-sounding doctrine;
- transferable rules from prior SOP, continuity hardening, research practice, environment identity, and RES design were generalized and given explicit authority classes/ceilings;
- exact R3.1 ancestry is preserved without changing its historical identity;
- primary verifier PASS;
- hostile mutation suite 12/12 rejected;
- clean-extraction replay is required before the outer ZIP is reported as sealed.

## Authority effect
This promotion makes R4.0 the canonical in-house process/cold-start SOP default. It does not create product, domain, architecture, legal, or scientific-result authority. Project-local standing obligations continue to govern their own scopes.

`CANONICAL_PROCESS_DEFAULT != UNIVERSAL_DOMAIN_TRUTH`
