# Trace Matrix — Through Local MS1944 Seal

| Claim | Evidence | Verification | Status |
|---|---|---|---|
| Canonical Main-Dev promoted | authority split | remains MS1527 | REJECTED |
| Current local descendant published remotely | remote refs | both still `3473834...` | REJECTED |
| Current sealed local research head | Git readback | `18696b19bf090ace01e6a4d2226b7b88609a3ad0` | VERIFIED LOCAL |
| Current local tree | Git readback | `de240e3424debf7d170bf29d24dc3c564518c753` | VERIFIED |
| Current validated source/test subject | MS1944 integrated validator | `ead0ad92ec0d4cb4c8d2df63f8e837b980a1aa515daf339b0147da84a89cdf14` stable | VERIFIED |
| Opaque signaling implies reference/meaning | MS1940 authority checks | no semantic authority | REJECTED |
| Learned signal response can re-enter rehearsal | MS1941 | exact subject-bound qualified relation -> zero-row rehearsal | VERIFIED UNDER FIXTURE |
| `REHEARSABLE == EXECUTABLE` | MS1941/MS1939 authority split | separate commitment required | REJECTED |
| Discovered motif regulatory bearing implies meaning | MS1942 | read-only value-bound disposition only | REJECTED |
| Individually current source rows necessarily form one subject | MS1942 hostile | nonuniform ancestry abstains | REJECTED |
| One signal miss proves predictive drift | MS1943 isolated miss | current at 0.875 window accuracy | REJECTED |
| Transient bad predictive window proves convention change | MS1943 recovery hostile | `[0.0,1.0]` remains current | REJECTED |
| Sustained contradictory signal outcomes can stale learned predictive relation | MS1943 | two consecutive failing windows | VERIFIED UNDER DECLARED BOUNDS |
| Learned predictive staleness automatically stales coordination | exact coordination subject readback | unchanged/current | REJECTED |
| Predictive drift identifies semantic convention change | authority surface | semantic-regime authority `NONE` | REJECTED |
| Drift replacement candidate is automatically qualified | MS1943 | qualification authority `NONE` | REJECTED |
| Later matching outcomes auto-reactivate old stale relation | MS1943 | durable drift witness remains negative | REJECTED |
| Fresh exact holdout can qualify signal replacement | MS1944 | replacement becomes current relation | VERIFIED UNDER FIXTURE |
| Fresh replacement qualification rewrites coordination | exact subject readback | epoch/signature/currentness unchanged | REJECTED |
| Qualified replacement implies semantic convention identity | MS1944 authority checks | none | REJECTED |
| Qualified zero-benefit replacement cannot appear in rehearsal | MS1944 falsifying probe | model proposal does appear | REJECTED |
| Rehearsal re-entry implies action indication | MS1944 | commitment `UNKNOWN / NO_DISCRIMINATING_REGULATORY_ADVANTAGE`; intent ABSTAIN | REJECTED |
| `CURRENT_PREDICTIVE_RELATION == CURRENT_ACTION_LICENSE` | MS1944 | separate commitment denies equivalence | REJECTED |
| MS1943 integrated compatibility | `job-67eb0930613c` | 186 files / 705 PASS / exact-once / compileall / stable | VERIFIED |
| MS1943 post-commit focused | `job-20795d4eab2f` | 14/14 PASS | VERIFIED |
| MS1944 focused boundary | `job-6373ff937206` | 15/15 PASS | VERIFIED |
| MS1944 integrated compatibility | `job-4254ab6a2c9b` | 187 files / 708 PASS / exact-once / 0 negative/terminal unknown / compileall / stable | VERIFIED |
| MS1944 post-commit focused | `job-3ed629df0620` | 3/3 PASS | VERIFIED |
| First MS1944 probe field error is negative science | no scientific assertion reached | fixture field invalid | REJECTED / INVALID_RUN |
| Second MS1944 probe expectation `rehearsal=None` was correct | reached discriminator | proposal returned | REJECTED / FALSIFIED EXPECTATION |
| RAHL SOP active | doctrine amendment | SHA `1f022bb0...` | VERIFIED / ACTIVE |
| Novelty established by MS1940–MS1944 | bounded integration tests only | no novelty adjudication | REJECTED / NOT ENTITLED |

## Earned scars / boundaries
- `SIGNAL != REFERENCE`.
- `TOKEN_EMITTED != TOKEN_MEANS`.
- `LEARNED_SIGNAL_RESPONSE != TOKEN_MEANING`.
- `REHEARSABLE != EXECUTABLE`.
- `PREDICTIVE_DRIFT != SEMANTIC_CONVENTION_CHANGE`.
- `LEARNED_RELATION_EMPIRICAL_STALENESS != COORDINATION_CONTRACT_STALENESS`.
- `REPLACEMENT_CANDIDATE != QUALIFIED_REPLACEMENT_RELATION`.
- `FRESH_REPLACEMENT_QUALIFICATION != SEMANTIC_CONVENTION_IDENTIFICATION`.
- `QUALIFIED_REPLACEMENT_MODEL != COORDINATION_CONTRACT_REWRITE`.
- `REHEARSAL_REENTRY != ACTION_INDICATION`.
- `QUALIFIED_REPLACEMENT_MODEL != DISCRIMINATING_REGULATORY_ROUTE`.
- `CURRENT_PREDICTIVE_RELATION != CURRENT_ACTION_LICENSE`.
- `INVALID_RUN != NEGATIVE_RESULT`.
- `CONSTITUENT_PASS != INTEGRATED_PASS`.

## Local lineage
`3473834 -> 6f816dd -> 2da2902 -> 4c46d21 -> ce53da1 -> 18696b1`.

## Current checkpoint
`notes/maintenance/MS1943_MS1944_LOCAL_CHECKPOINT_2026-08-29.md`
SHA `8b7642162b0d18c4d46b8a2bdad2273bff42cf8dfbaa2f488db7024c4cf04871`.

## Next claim under test
MS1945 represented-alternative selection:
`TWO_REPRESENTED_OPAQUE_SIGNALS + CURRENT_QUALIFIED_PREDICTIONS -> REGULATORY_SELECTION_WITHOUT_SEMANTIC_POLICY ?`

Prewrite:
- `REPRESENTED_SIGNAL_ALTERNATIVE != TOKEN_MEANING`;
- `PREDICTIVE_SELECTION != SEMANTIC_REFERENCE`;
- `ACTION_SELECTION_AMONG_REPRESENTED_TOKENS != ENDOGENOUS_TOKEN_INVENTION`.

## Novelty posture
`UNKNOWN / NOT_ENTITLED_TO_CLAIM`.
