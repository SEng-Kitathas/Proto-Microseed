# Next Steps — After Local MS1944 Seal

## Current local descendant
- HEAD: `18696b19bf090ace01e6a4d2226b7b88609a3ad0`;
- tree: `de240e3424debf7d170bf29d24dc3c564518c753`;
- validated source/test snapshot: `ead0ad92ec0d4cb4c8d2df63f8e837b980a1aa515daf339b0147da84a89cdf14`;
- worktree clean;
- public GitHub still at MS1939 `3473834da0ce1bbc0db16a35f4b9b8e2fa551ee2`.

## Qualification
MS1944 integrated validator `job-4254ab6a2c9b`:
- 187/187 test files exact-once;
- 708 aggregate PASS;
- negative groups `[]`;
- terminal unknown groups `[]`;
- compileall PASS;
- source/test subject stable.

Post-commit focused `job-3ed629df0620`: 3/3 PASS.

## Immediate P0 — MS1945 represented-alternative signal selection
Question:

> If two opaque signal capabilities (`T0`, `T1`) are already represented, can admitted history + exact subject-bound qualification make ordinary rehearsal select the currently regulatory-useful represented signal without a semantic token registry or an externally supplied consumer-choice policy?

### Required boundaries
- `REPRESENTED_SIGNAL_ALTERNATIVE != TOKEN_MEANING`;
- `PREDICTIVE_SELECTION != SEMANTIC_REFERENCE`;
- `CURRENT_USEFUL_SIGNAL != CONVENTION_IDENTITY`;
- `ACTION_SELECTION_AMONG_REPRESENTED_TOKENS != ENDOGENOUS_TOKEN_INVENTION`;
- `REHEARSAL_PROPOSAL != ACTION_INDICATION`;
- `MODEL_CURRENTNESS_OWNER != COORDINATION_CURRENTNESS_OWNER`.

### Experiment order
1. Inspect existing multi-option rehearsal and learned-relation selection before designing code.
2. Represent both opaque signal effects explicitly; do not invent `T1` inside the learner.
3. Learn/qualify outcome relations from admitted history with exact subject binding.
4. Composition-only test first.
5. Make the environmental response favor one represented token, then reverse under separately qualified/current evidence.
6. Verify selection follows current predicted regulatory effect, not token identity/lexical order.
7. Attack ties, stale relation, coordination drift, and semantically misleading token labels.
8. Require bounded action commitment separately from rehearsal selection.
9. If composition closes, regression evidence only; patch production code only on an isolated missing mechanism.

## Secondary frontiers
- Reference/language: deferred. `SIGNAL != REFERENCE`; `TOKEN_EMITTED != TOKEN_MEANS`.
- Endogenous token invention: NOT OPENED by represented-alternative selection.
- General signal policy/selector subsystem: NOT AUTHORIZED by this question alone.
- Blind external challenge: priority on arrival.
- NAKED unknown-route exploration: blocked on normative authority.
- EQUIPPED/FEDERATED warrant: design-supported / explicit build objective required.
- Project-control compact readback: optional, not organism default.

## Publication
Do not push MS1940–MS1944 automatically. Publication remains a separate transaction.

## Novelty
`UNKNOWN / NOT_ENTITLED_TO_CLAIM`.
