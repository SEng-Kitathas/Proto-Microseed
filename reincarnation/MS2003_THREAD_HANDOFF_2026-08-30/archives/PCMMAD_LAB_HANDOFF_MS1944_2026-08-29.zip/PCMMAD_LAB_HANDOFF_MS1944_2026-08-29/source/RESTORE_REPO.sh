#!/usr/bin/env sh
set -eu
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
TARGET="$(dirname "$HERE")/restored_research_ms1888_replay"
git clone "$HERE/PROTO_MICROSEED_MS1944.bundle" "$TARGET"
git -C "$TARGET" checkout -b 'research/ms1888-replay' 'origin/research/ms1888-replay'
git -C "$TARGET" rev-parse HEAD
git -C "$TARGET" rev-parse 'HEAD^{tree}'
git -C "$TARGET" status --short --branch
# Expected HEAD: 18696b19bf090ace01e6a4d2226b7b88609a3ad0
# Expected tree: de240e3424debf7d170bf29d24dc3c564518c753
