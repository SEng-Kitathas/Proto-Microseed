$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target = Join-Path (Split-Path -Parent $Here) 'restored_research_ms1888_replay'
git clone (Join-Path $Here 'PROTO_MICROSEED_MS1944.bundle') $Target
git -C $Target checkout -b 'research/ms1888-replay' 'origin/research/ms1888-replay'
git -C $Target rev-parse HEAD
git -C $Target rev-parse 'HEAD^{tree}'
git -C $Target status --short --branch
# Expected HEAD: 18696b19bf090ace01e6a4d2226b7b88609a3ad0
# Expected tree: de240e3424debf7d170bf29d24dc3c564518c753
