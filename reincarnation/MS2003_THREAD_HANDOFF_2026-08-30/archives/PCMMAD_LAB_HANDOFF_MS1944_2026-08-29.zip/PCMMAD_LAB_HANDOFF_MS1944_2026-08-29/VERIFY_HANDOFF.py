#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
man=json.loads((ROOT/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
issues=[]
for rel,meta in man.items():
 p=ROOT/rel
 if not p.is_file(): issues.append('MISSING:'+rel); continue
 if hashlib.sha256(p.read_bytes()).hexdigest()!=meta['sha256']: issues.append('HASH:'+rel)
 if p.stat().st_size!=meta['bytes']: issues.append('SIZE:'+rel)
actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST_SHA256.json'}
expected=set(man)
issues += ['EXTRA:'+x for x in sorted(actual-expected)]
issues += ['UNDECLARED_MISSING:'+x for x in sorted(expected-actual)]
print(json.dumps({'status':'PASS' if not issues else 'FAIL','files':len(man),'issues':issues},indent=2))
raise SystemExit(0 if not issues else 1)
